python3 runner.py $1
